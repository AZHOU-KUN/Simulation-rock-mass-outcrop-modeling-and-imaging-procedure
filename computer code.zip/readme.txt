The name of the program: Simulation rock mass outcrop modeling and imaging procedure

The title of the manuscript: Accuracy comparison of geometric parameters of digital outcrop models reconstructed based on camera positions and control points by a numerical simulation procedure of photogrammetry

The author details: Bohu Zhang a, b, Wankun Li a, b, Jun Zheng c *, Qing L�� c 
a State Key Laboratory of Oil and Gas Reservoir Geology and Exploitation, Southwest Petroleum University, Chengdu, Sichuan, 610500, China
b School of Geoscience and Technology, Southwest Petroleum University, Chengdu 610500, China
c Department of Civil Engineering, Zhejiang University, Hangzhou 310058, China
*Corresponding Author: E-mail address: zhengjun12@zju.edu.cn; Telephone: +86 15356156332
